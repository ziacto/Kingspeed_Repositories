# UIImage Filters

Sample Usage:

	    self.blurredImageView.image = [UIImage blur:self.blurredImageView.image radius:9.0];
