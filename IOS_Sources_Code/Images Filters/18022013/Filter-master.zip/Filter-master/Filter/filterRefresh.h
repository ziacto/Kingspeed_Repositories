//
//  filterRefresh.h
//  Filter
//
//  Created by François Guillemé on 7/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol layerAction <NSObject>
-(void)refresh;
-(void)addNewLayer;
@end
