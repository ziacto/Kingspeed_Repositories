Filter
======

a iOS iPad demo program of Core Image filter (should work fine on iOS5 but dev on iOS6