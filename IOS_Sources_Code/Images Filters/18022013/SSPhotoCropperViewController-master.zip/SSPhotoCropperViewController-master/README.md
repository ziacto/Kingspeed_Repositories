SSPhotoCropperViewController is a custom view controller that provides UI for cropping and scaling photos in iPhone / iPod Touch apps.

More info at:
http://www.ardalahmet.com/2011/10/17/ssphotocropperviewcontroller-a-custom-viewcontroller-that-provides-ui-for-cropping-photos-in-ios-apps/

For any questions and suggestions contact me at:
http://twitter.com/ardalahmet
or
ardalahmet(at)gmail.com

Licensed under the Apache License, Version 2.0 (the "License").
See LICENSE.txt or visit http://www.apache.org/licenses/LICENSE-2.0 for more information.


SSPhotoCropperViewController Demo App Screenshots:

![SSPhotoCropperViewController Demo App Screenshot - 1](http://farm8.staticflickr.com/7166/6838095697_f4015a8139_z.jpg)

![SSPhotoCropperViewController Demo App Screenshot - 2](http://farm8.staticflickr.com/7035/6838101557_1cb81d0b7a_z.jpg)
