//
//  main.m
//  PhotoFilters
//
//  Created by Roberto Breve on 6/3/12.
//  Copyright (c) 2012 Icoms. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PhotoFilterAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PhotoFilterAppDelegate class]));
    }
}
