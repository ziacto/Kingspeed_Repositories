//
//  PhotoFilterAppDelegate.h
//  PhotoFilters
//
//  Created by Roberto Breve on 6/3/12.
//  Copyright (c) 2012 Icoms. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoFilterAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
