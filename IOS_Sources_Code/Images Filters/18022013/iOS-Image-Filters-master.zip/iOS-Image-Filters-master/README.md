#ImageFilter
————————————————————————————————————————————
##High-level image filtering on iOS 5+

* Overlay image Photoshop style for custom effects
* Also sepia, black & white, hue & saturation, brightness, contrast, etc.
* Inspired initially by Eric Silverberg's pre-iOS 5 class
* Requires my one-file CCMacros project here on GitHub as well as one class from MGImageUtilities
* Includes several retina & non-retina images for my custom effects lossely based on some popular ones in tap tap tap's Camera+ (Camera Plus as some type)