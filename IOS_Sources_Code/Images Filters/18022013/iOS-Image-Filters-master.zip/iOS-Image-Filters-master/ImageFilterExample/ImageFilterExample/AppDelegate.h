//
//  AppDelegate.h
//  ImageFilterExample
//
//  Created by James Womack on 7/16/12.
//  Copyright (c) 2012 James Womack. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
