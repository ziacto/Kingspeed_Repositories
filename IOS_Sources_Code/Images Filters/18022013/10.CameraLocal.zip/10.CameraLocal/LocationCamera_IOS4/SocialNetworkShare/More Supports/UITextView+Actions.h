/***********************************************************************
 *	File name:	UITextViewPerformAction.h
 *	Project:	
 *	Description:
 *  Author:		
 *  Created:    on 3/1/12.
 *	Device:		Iphone vs IPad
 *  Company:	__MyCompanyName__
 *  Copyright:	2012 . All rights reserved.
 ***********************************************************************/

#import <UIKit/UIKit.h>

@interface UITextViewPerformAction : UITextView
{

}

@end
