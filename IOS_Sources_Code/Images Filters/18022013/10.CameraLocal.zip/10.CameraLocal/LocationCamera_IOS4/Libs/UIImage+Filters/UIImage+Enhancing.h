//
//  UIImage+Enhancing.h
//  NYXImagesKit
//
//  Created by @Nyx0uf on 03/12/11.
//  Copyright 2012 Nyx0uf. All rights reserved.
//  www.cocoaintheshell.com
//


@interface UIImage (NYX_Enhancing)

-(UIImage*)autoEnhance;

-(UIImage*)redEyeCorrection;

@end
