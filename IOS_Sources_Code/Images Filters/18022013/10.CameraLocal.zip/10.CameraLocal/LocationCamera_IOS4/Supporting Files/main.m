//
//  main.m
//  LocationCamera
//
//  Created by iMac02 on 31/1/2013.
//  Copyright (c) 2013 iMac02. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
