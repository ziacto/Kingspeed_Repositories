//
//  XBGLShaderAttribute.m
//  XBImageFilters
//
//  Created by xiss burg on 2/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "XBGLShaderAttribute.h"

@implementation XBGLShaderAttribute

@end
