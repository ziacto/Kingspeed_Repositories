//
//  XBFilteredImageView.h
//  XBImageFilters
//
//  Created by xiss burg on 2/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XBFilteredView.h"

@interface XBFilteredImageView : XBFilteredView

@property (strong, nonatomic) UIImage *image;

@end
