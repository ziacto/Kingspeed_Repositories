Version 1.1

- Updated to use ARC
- Added podspec

Version 1.0

- Initial release