#import <UIKit/UIKit.h>
#import "GPUImage.h"
#import "SimpleImageViewController.h"

@interface SimpleImageAppDelegate : UIResponder <UIApplicationDelegate>
{
    SimpleImageViewController *rootViewController;
}

@property (strong, nonatomic) UIWindow *window;

@end
