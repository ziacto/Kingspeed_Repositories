#import "GPUImageTwoInputFilter.h"

@interface GPUImageMultiplyBlendFilter : GPUImageTwoInputFilter
{
}

@end
