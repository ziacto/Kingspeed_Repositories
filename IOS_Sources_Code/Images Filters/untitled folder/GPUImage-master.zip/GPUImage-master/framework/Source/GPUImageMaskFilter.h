#import "GPUImageTwoInputFilter.h"

@interface GPUImageMaskFilter : GPUImageTwoInputFilter

@end
