//
//  ScreenshotsAppDelegate.h
//  Screenshots
//
//  Created by James Hillhouse on 3/22/11.
//  Copyright 2011 PortableFrontier. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScreenshotsAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain)       IBOutlet    UIWindow                 *window;
@property (nonatomic, retain)       IBOutlet    UINavigationController   *navigationController;

@end
