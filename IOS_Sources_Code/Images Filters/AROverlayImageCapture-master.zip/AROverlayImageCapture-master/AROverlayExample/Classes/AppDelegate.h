#import <UIKit/UIKit.h>

@class AROverlayViewController;

@interface AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet AROverlayViewController *viewController;

@end
