//
//  main.m
//  dispatch-cancel
//
//  Created by Jerry Jones on 12/11/11.
//  Copyright (c) 2011 Spaceman Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SMAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([SMAppDelegate class]));
	}
}
